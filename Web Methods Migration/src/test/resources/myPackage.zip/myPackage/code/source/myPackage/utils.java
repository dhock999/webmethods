package myPackage;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void manifestParse (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(manifestParse)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		IDataMap idm = new IDataMap(pipeline);
		String packageName = idm.getAsString("packageName");
		
		String filename = ".../IntegrationServer/packages/" + packageName + "/manifest.v3";
		  java.io.InputStream in = null;
		
		  try {
		    in = new java.io.BufferedInputStream(new java.io.FileInputStream(filename));
		    com.wm.util.coder.XMLCoderWrapper codec = new com.wm.util.coder.XMLCoderWrapper();
		    com.wm.data.IData manifestDocument = codec.decode(in);
		
		    com.wm.data.IDataCursor manifestCursor = manifestDocument.getCursor();
		    com.wm.data.IData requiresDocument = com.wm.data.IDataUtil.getIData(manifestCursor, "requires");
		    manifestCursor.destroy();
		
		    java.util.List<String> dependencies = new java.util.ArrayList<String>();
		    if (requiresDocument != null) {
		      com.wm.data.IDataCursor requiresCursor = requiresDocument.getCursor();
		
		      while(requiresCursor.next()) {
		        String dependency = requiresCursor.getKey();
		        String version = (String)requiresCursor.getValue();
		
		        dependencies.add(dependency);
		      }
		      requiresCursor.destroy();
		    }
		
		    return dependencies.toArray(new String[dependencies.size()]);
		  } finally {
		    if (in != null) in.close();
		  }
			
		// --- <<IS-END>> ---

                
	}



	public static final void remDupFromStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(remDupFromStringList)>> ---
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:1:required outStringList
		// pipeline
		IDataMap idm = new IDataMap(pipeline);
		
		String[] inStringList = idm.getAsStringArray("inStringList");
		List<String> list = Arrays.asList(inStringList);
		Set<String> set = new HashSet<String>(list);
		String[] result = new String[set.size()];
		set.toArray(result);
		
		// pipeline
		idm.put("outStringList", result);
			
		// --- <<IS-END>> ---

                
	}
}

