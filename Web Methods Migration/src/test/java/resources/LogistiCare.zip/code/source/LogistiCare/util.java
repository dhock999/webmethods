package LogistiCare;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2017-03-15 10:12:16 EDT
// -----( ON-HOST: vvavac60376.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void new_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(new_javaService)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}



	public static final void remDupFromStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(remDupFromStringList)>> ---
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:1:required outStringList
		// pipeline
		IDataMap idm = new IDataMap(pipeline);
		
		String[] inStringList = idm.getAsStringArray("inStringList");
		List<String> list = Arrays.asList(inStringList);
		Set<String> set = new HashSet<String>(list);
		String[] result = new String[set.size()];
		set.toArray(result);
		
		// pipeline
		idm.put("outStringList", result);
			
		// --- <<IS-END>> ---

                
	}
}

